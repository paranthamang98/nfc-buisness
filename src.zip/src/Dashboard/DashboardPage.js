import React ,{useState} from 'react'
import  logo from '../image/Group 19.png'
import Header from './Header'
import SideMenu from './SideMenu'

function DashboardPage() {

  const [showSidebar, setShowSidebar] = useState(true);

    const onSidebar = () => {
        setShowSidebar(!showSidebar);
    };
  return (
    <>
      <Header onSidebar={onSidebar}/>
     {showSidebar? <SideMenu />:null}
    </>
  )
}

export default DashboardPage
