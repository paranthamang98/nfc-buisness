import Login from "./Component/Login";
import DashboardPage from "./Dashboard/DashboardPage";
import Header from "./Dashboard/Header";
import SideMenu from "./Dashboard/SideMenu";

function App() {
  return (
   <div>
   <DashboardPage/>
   <Login/>
     
   </div>
  );
}

export default App;
