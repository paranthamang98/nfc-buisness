import React from 'react'

function ManageContact() {
  return (
    <div>
      
    </div>
  )
}

export default ManageContact
