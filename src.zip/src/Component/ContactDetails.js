import React from 'react'

function ContactDetails() {
  return (
    <div>
      
    </div>
  )
}

export default ContactDetails
