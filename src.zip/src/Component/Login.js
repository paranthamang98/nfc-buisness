import React,{useState} from 'react'
import  logo from '../image/Group 19.png'
import  banner from '../image/Group 1925.png'
import '../Component/login.css'

function Login() {
    const [showtype, setShowtype] = useState(true);
    const changingType = () =>{
        setShowtype(!showtype);

    }
  return (
    <div className='main-login row '>
        <div className='col-6 mob'>
            <img src={banner}/>
        </div>
        <div className='col-6 login_input '>
       <div className='login_inner'>
       <div className='login_logo'>
       <img src={logo}/>
       </div>
       <h6 className='login_header'>Login</h6>
       <form>
           <div className='email_item'>
               <div className='email_icon'></div>
               <ladle>Email Id</ladle>
               <input type='email'/>
           </div>
           <div className='password_item'>
               <div className='password_icon'></div>
               <ladle>Password</ladle>
               <input type={showtype? 'password':'text'}/>
               <div onClick={changingType} className='i_icon'></div>
           </div>
           <div className='last_forgot'>
               <p className='remember'><input type='checkbox'/>Remember me</p>
               <p className='forgot'>Forgot Password?</p>
           </div>
           <div>
               <input type='submit' value='LOGIN'/>
           </div>
       </form>
       </div>
        </div>

     
    </div>
  )
}

export default Login
