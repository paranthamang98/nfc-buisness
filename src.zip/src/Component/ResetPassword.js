import React from 'react'

function ResetPassword() {
  return (
    <div>
      
    </div>
  )
}

export default ResetPassword
