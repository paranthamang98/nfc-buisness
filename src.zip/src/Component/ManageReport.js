import React from 'react'

function ManageReport() {
  return (
    <div>
      
    </div>
  )
}

export default ManageReport
