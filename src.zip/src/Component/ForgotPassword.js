import React from 'react'

function ForgotPassword() {
  return (
    <div>
      
    </div>
  )
}

export default ForgotPassword
